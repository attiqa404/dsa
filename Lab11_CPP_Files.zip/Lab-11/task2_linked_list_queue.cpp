#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

class LinkedListQueue {
    Node *front, *rear;
public:
    LinkedListQueue() {
        front = rear = nullptr;
    }

    void enqueue(int val) {
        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = nullptr;
        if (rear == nullptr) {
            front = rear = newNode;
            return;
        }
        rear->next = newNode;
        rear = newNode;
    }

    int countNodes() {
        int count = 0;
        Node* temp = front;
        while (temp != nullptr) {
            count++;
            temp = temp->next;
        }
        return count;
    }

    void displayRear() {
        if (rear == nullptr) {
            cout << "Queue is empty. No rear element.\n";
            return;
        }
        cout << "Rear element: " << rear->data << "\n";
    }

    void clearQueue() {
        Node* current = front;
        while (current != nullptr) {
            Node* nextNode = current->next;
            delete current;
            current = nextNode;
        }
        front = rear = nullptr;
        cout << "Queue cleared and memory freed.\n";
    }

    void display() {
        Node* temp = front;
        cout << "Queue elements: ";
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << "\n";
    }
};

int main() {
    LinkedListQueue q;

    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.enqueue(40);
    q.enqueue(50);

    q.display();
    cout << "Total nodes: " << q.countNodes() << "\n";
    q.displayRear();

    cout << "\nClearing queue...\n";
    q.clearQueue();
    cout << "Total nodes after clearing: " << q.countNodes() << "\n";

    return 0;
}

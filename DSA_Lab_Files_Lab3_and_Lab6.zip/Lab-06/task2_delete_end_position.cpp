#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void deleteAtEnd(Node*& head) {
    if (head == nullptr) return;

    if (head->next == nullptr) {
        delete head;
        head = nullptr;
        return;
    }

    Node* temp = head;
    while (temp->next->next != nullptr) {
        temp = temp->next;
    }
    delete temp->next;
    temp->next = nullptr;
}

void deleteAtPosition(Node*& head, int pos) {
    if (head == nullptr) return;

    if (pos == 1) {
        Node* temp = head;
        head = head->next;
        delete temp;
        return;
    }

    Node* temp = head;
    for (int i = 1; i < pos - 1 && temp != nullptr; i++) {
        temp = temp->next;
    }

    if (temp == nullptr || temp->next == nullptr) return;

    Node* deleteNode = temp->next;
    temp->next = deleteNode->next;
    delete deleteNode;
}

void display(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data;
        if (temp->next != nullptr) cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    Node* head = new Node{10, new Node{20, new Node{30, new Node{40, new Node{50, nullptr}}}}};

    cout << "Initial List: ";
    display(head);

    deleteAtEnd(head);
    cout << "After deleting last node: ";
    display(head);

    deleteAtPosition(head, 2);
    cout << "After deleting at position 2: ";
    display(head);

    return 0;
}

#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void deleteAtStart(Node*& head) {
    if (head == nullptr) {
        cout << "List is empty.\n";
        return;
    }
    Node* temp = head;
    head = head->next;
    delete temp;
}

void display(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data;
        if (temp->next != nullptr) cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    Node* head = new Node{10, new Node{20, new Node{30, new Node{40, new Node{50, nullptr}}}}};

    cout << "Initial List: ";
    display(head);

    deleteAtStart(head);
    cout << "After 1st deletion: ";
    display(head);

    deleteAtStart(head);
    cout << "After 2nd deletion: ";
    display(head);

    return 0;
}

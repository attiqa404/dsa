#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void deleteByValue(Node*& head, int value) {
    if (head == nullptr) {
        cout << "Value not found" << endl;
        return;
    }

    if (head->data == value) {
        Node* temp = head;
        head = head->next;
        delete temp;
        return;
    }

    Node* temp = head;
    while (temp->next != nullptr && temp->next->data != value) {
        temp = temp->next;
    }

    if (temp->next != nullptr) {
        Node* deleteNode = temp->next;
        temp->next = deleteNode->next;
        delete deleteNode;
    } else {
        cout << "Value not found" << endl;
    }
}

void display(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data;
        if (temp->next != nullptr) cout << " -> ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    Node* head = new Node{10, new Node{20, new Node{30, new Node{40, nullptr}}}};

    cout << "Initial List: ";
    display(head);

    deleteByValue(head, 10);
    cout << "After deleting 10: ";
    display(head);

    deleteByValue(head, 30);
    cout << "After deleting 30: ";
    display(head);

    deleteByValue(head, 99);

    return 0;
}
